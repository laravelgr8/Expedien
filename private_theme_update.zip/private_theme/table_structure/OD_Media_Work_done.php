CREATE TABLE OD_Media_Work_done(
	OD_Media_Type int,
	OD_Media_ID varchar(20),
	Line_No int,
	Work_Name varchar(100),
	Year varchar(4),
	Qty_Of_Display_Duration int,
	Billing_Amount decimal(38, 20),
	File_Name varchar(50),
	File_Uploaded int,
 
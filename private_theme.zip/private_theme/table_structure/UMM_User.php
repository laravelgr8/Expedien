CREATE TABLE UMM_User (
    UserType int(11),
    UserID varchar(255),
    UserName varchar(255),
    Email varchar(255),
    Password varchar(255)
);
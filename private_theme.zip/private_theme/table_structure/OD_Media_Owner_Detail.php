CREATE TABLE OD_Media_Owner_Detail(
	timestamp timestamp,
	OD_Media_Type int,
	OD_Media_ID varchar(20),
	Owner_ID varchar(20),

// Alphabetic validation
function alphaOnly(event) {
  var inputValue = event.charCode;
      if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)){
          event.preventDefault();
    }
}


	function onlyAlphabets(e, t) {
			try {
				if (window.event) {
					var charCode = window.event.keyCode;
				}
				else if (e) {
					var charCode = e.which;
				}
				else { return true; }
				if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32) || (charCode == 45))
					return true;
				else
					return false;
			}
			catch (err) {
				alert(err.Description);
			}
		}

    function onlyNumberKey(evt) {  
      var ASCIICode = (evt.which) ? evt.which : evt.keyCode
      if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
      return false;
      return true;
    }
    

$(document).ready(function(){
  $(".media-producers-next-button").click(function(){
    var form = $("#av_media_producers");        
    form.validate({
      rules: {   
           
            email: {
             
              email: true
            },
            mobile: {
              minlength: 10,
              maxlength: 10,
              number:true
            },
           
            phone: {
              minlength: 15,

              maxlength: 15,
              number:true
            },
            std: {
              required:true,
              maxlength: 10,
              number:true
            },
            fax: {
              maxlength: 15,
              number:true
            }, 
          fax_no: {
              maxlength: 15,
              number:true
            },
          landline_no: {
              maxlength: 15,
              number:true
            },
            office_telephone_no: {
              maxlength: 15,
              number:true
            },
             resident_telephone_no: {
              maxlength: 15,
              number:true
            },

   
        },
        messages: {      
        
          email: {
            
            email: "Please enter a vaild email address!"
          },
        
          mobile: {
            
            maxlength: "Mobile length should be max and min 10 digit!",
            number: "Users can enter only integer numbers!"
          },
        
          phone: {
            minlength:"Mobile length should be max and min 15 digit!",
            maxlength: "Mobile length should be max and min 15 digit!",
            number: "Users can enter only integer numbers!"
          },
          std:{
            maxlength: "STD length should be max and min 10 digit!",
              number: "Users can enter only integer numbers!"
            },
          fax: {
            maxlength: "Fax length should be max and min 15 digit!",
            number: "Users can enter only integer numbers!"
          },
          fax_no: {
            maxlength: "Fax length should be max and min 15 digit!",
            number: "Users can enter only integer numbers!"
          },
          landline_no: {
            maxlength: "Fax length should be max and min 15 digit!",
            number: "Users can enter only integer numbers!"
          },
           office_telephone_no: {
            maxlength: "Fax length should be max and min 15 digit!",
            number: "Users can enter only integer numbers!"
          },
          resident_telephone_no: {
            maxlength: "Fax length should be max and min 15 digit!",
            number: "Users can enter only integer numbers!"
          },

         
        //   terms: "Please accept our terms"
        },
        errorElement: 'span',
        errorPlacement: function (error, element) {
          error.addClass('invalid-feedback');
          element.closest('.form-group').append(error);
        },
        highlight: function (element, errorClass, validClass) {
          $(element).addClass('is-invalid');
        },
        unhighlight: function (element, errorClass, validClass) {
          $(element).removeClass('is-invalid');
        }
    });
    if (form.valid() === true) {
      if ($('#tab1').is(":visible")) {
        current_fs = $('#tab1');
        next_fs = $('#tab2');
        $("a[href='#tab1']").removeClass("active");
        $("a[href='#tab2']").addClass("active");
        // nextSaveData('next_tab_1');
        $("#next_tab_1").val("0");

      } else if ($('#tab2').is(":visible")) {
        current_fs = $('#tab2');
        next_fs = $('#tab3');
        $("a[href='#tab2']").removeClass("active");
        $("a[href='#tab3']").addClass("active");
        // nextSaveData('next_tab_2');
        $("#next_tab_2").val("0");

      } else if ($('#tab3').is(":visible")) {
        current_fs = $('#tab3');
        next_fs = $('#tab4');
        $("a[href='#tab3']").removeClass("active");
        $("a[href='#tab4']").addClass("active");
        // nextSaveData('next_tab_3');
        $("#next_tab_3").val("0");
      }
      
      next_fs.show();
      current_fs.hide();
    }
  });
  $('.reg-previous-button').click(function () {
    if ($('#tab2').is(":visible")) {
      current_fs = $('#tab2');
      next_fs = $('#tab1');
      $("a[href='#tab2']").removeClass("active");
      $("a[href='#tab1']").addClass("active");
      $("#next_tab_3").val("0");

    } else if ($('#tab3').is(":visible")) {
      current_fs = $('#tab3');
      next_fs = $('#tab2');
      $("a[href='#tab3']").removeClass("active");
      $("a[href='#tab2']").addClass("active");

    } else if ($('#tab4').is(":visible")) {
      current_fs = $('#tab4');
      next_fs = $('#tab3');
      $("a[href='#tab4']").removeClass("active");
      $("a[href='#tab3']").addClass("active");
    }

    next_fs.show();
    current_fs.hide();
  });
//jquery required validation on next button
// $(function () {

//     $.validator.setDefaults({
//       submitHandler: function () {
//         stepper.next()
//         // alert( "Form successful submitted!" );
//       }
//   });
//email validation formate
jQuery.validator.addMethod("emailExt", function(value, element, param) {
return value.match(/^[a-zA-Z0-9_\.%\+\-]+@[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,}$/);
},'Please enter a vaild email address');

});



function onlyAlphabets(e, t) {
  try {
      if (window.event) {
          var charCode = window.event.keyCode;
      }
      else if (e) {
          var charCode = e.which;
      }
      else { return true; }
      if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32))
          return true;
      else
          return false;
  }
  catch (err) {
      alert(err.Description);
  }

} 

///alpha numeric
function isAlphaNumeric(e){ // Alphanumeric only
  var k;
  document.all ? k=e.keycode : k=e.which;
  return((k>47 && k<58)||(k>64 && k<91)||(k>96 && k<123)||k==0);
}

function onlyNumberKey(evt) {

// Only ASCII character in that range allowed
var ASCIICode = (evt.which) ? evt.which : evt.keyCode
if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
  return false;
return true;
}

// THE SCRIPT THAT CHECKS IF THE KEY PRESSED IS A NUMERIC OR DECIMAL VALUE.
function isNumber(evt, element) {

var charCode = (evt.which) ? evt.which : event.keyCode

if (
  (charCode != 45 || $(element).val().indexOf('-') != -1) &&      // Check minus and only once.
  (charCode != 46 || $(element).val().indexOf('.') != -1) &&      // Check dot and only once.
  (charCode < 48 || charCode > 57))
  return false;

return true;
}        
//float validation



//check fax length
function IsAlphaNumeric(e) {
            // alert(e.keyCode);
             var keyCode = e.keyCode == 0 ? e.charCode : e.keyCode;
             var ret = ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <=

 122) || (keyCode == 32));
             document.getElementById("error").style.display = ret ? "none" : "inline";
             return ret;
         }

         // alphanumeric
function Validate(e) {
  var keyCode = e.keyCode || e.which;
  var errorMsg = document.getElementById("lblErrorMsg");
  //errorMsg.innerHTML = "";

  //Regex to allow only Alphabets Numbers Dash Underscore and Space
  var pattern = /^[a-z\d\-_\s]+$/i;

  //Validating the textBox value against our regex pattern.
  var isValid = pattern.test(String.fromCharCode(keyCode));
  if (!isValid) {
    errorMsg.innerHTML = "Invalid Attempt, only alphanumeric, dash , underscore and space are allowed.";
  }

  return isValid;
}

$('#section_a').hide();
$('#section_b').hide();
$('#section_c').hide();
$('#category').change(function(){
  var category =$('#category option:selected').val();
  //alert(category);
  if(category == "0"){
    $('#section_a').show();
    $("#net_worth_b").attr('disabled');
    $("#details_programme_b").attr('disabled');
    $("#Channel_b").attr('disabled');
    $("#datepicker1_b").attr('disabled');
    $("#TRP_b").attr('disabled');
  }else{
    $('#section_a').hide();
  }
   if(category == "1"){
    $('#section_b').show();
    $("#net_worth_a").attr('disabled');
    $("#details_programme_a").attr('disabled');
    $("#Channel_a").attr('disabled');
    $("#datepicker1_a").attr('disabled');
    $("#TRP_a").attr('disabled');
  }else{
    $('#section_b').hide();
  }
    if(category == "2"){
    $('#section_c').show();
  }else{
    $('#section_c').hide();
  }

  // if(category == '0'){
  //   $('#section_a').show();
  // }else{
  //   $('#section_a').hide();
  // }
  //  if(category == '1'){
  //   $('#section_b').show();
  // }else{
  //   $('#section_b').hide();
  // }
  //   if(category == '2'){
  //   $('#section_c').show();
  // }else{
  //   $('#section_c').hide();
  // }
});



$('#category').change(function(){
  var category =$('#category option:selected').val();
  //alert(category);
  if(category == "0"){
    $("#net_worth_b").attr('disabled','disabled');
    $("#details_programme_b").attr('disabled','disabled');
    $("#Channel_b").attr('disabled','disabled');
    $("#datepicker1_b").attr('disabled','disabled');
    $("#TRP_b").attr('disabled','disabled');
  }else{
    // $('#section_a').hide();
    $("#net_worth_b").removeAttr('disabled');
    $("#details_programme_b").removeAttr('disabled');
    $("#Channel_b").removeAttr('disabled');
    $("#datepicker1_b").removeAttr('disabled');
    $("#TRP_b").removeAttr('disabled');
  }
   if(category == "1"){
    $("#net_worth_a").attr('disabled','disabled');
    $("#details_programme_a").attr('disabled','disabled');
    $("#Channel_a").attr('disabled','disabled');
    $("#datepicker1_a").attr('disabled','disabled');
    $("#TRP_a").attr('disabled','disabled');
  }else{
    // $('#section_b').hide();
    $("#net_worth_a").removeAttr('disabled');
    $("#details_programme_a").removeAttr('disabled');
    $("#Channel_a").removeAttr('disabled');
    $("#datepicker1_a").removeAttr('disabled');
    $("#TRP_a").removeAttr('disabled');
  }
    if(category == "2"){
      $("#net_worth_b").attr('disabled','disabled');
      $("#net_worth_a").attr('disabled','disabled');
    // $('#section_c').show();
  }else{
    // $('#section_c').hide();
    $("#net_worth_b").removeAttr('disabled');
    $("#net_worth_a").removeAttr('disabled');
  }


});
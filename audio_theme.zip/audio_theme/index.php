
<style>
  body {
    color: #6c757d !important;
  }
</style>  <!doctype html>
 <html lang="en">
 <head>
  <meta charset="utf-8">
  <meta id="Viewport" name="viewport" content="initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
  <!-- CSRF Token -->
  <meta name="csrf-token1" content="gR7vbGiaJ9fjZwTkAEyrVNrjQcagZ7VvbLBl3IEi">
  <title>Print Media</title>
  <link rel="dns-prefetch" href="//fonts.gstatic.com">

  <link href="bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="style.css" >
  <link rel="stylesheet" href="responsive.css">
  <link href="font-awesome.min.css" rel="stylesheet" />
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="OverlayScrollbars.min.css">
  <!-- daterange picker -->
  <link rel="stylesheet" href="daterangepicker.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="icheck-bootstrap.min.css">
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="bootstrap-colorpicker.min.css">
  <link rel="stylesheet" href="bootstrap-multiselect.css" />
  <!-- Select2 -->
  <link rel="stylesheet" href="select2.min.css">
  <link rel="stylesheet" href="select2-bootstrap4.min.css">
</head>
<body>
  <div id="app" >
        <div class="wrapper d-flex align-items-stretch">
     <!-- Start Sidebar -->
     <nav id="sidebar">
  <div class="sidebar-header">
    <!--<h3>Bootstrap Sidebar </h3>--> 
    <h3 class="inside-logo"><img class="logo" src="logo-s.png" /> <span class="mt-3"></span></h3>
  </div>

  <div class="p-3"> 
    <i class="fa fa-fw fa-align-left"></i> My Menu</p>
    <ul class="list-unstyled components mb-5">
                              
                      
                   <li>
                      <a href="#Empanelment" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-angle-right" aria-hidden="true"></i> Fresh Empanelment</a>
                      <ul class="collapse list-unstyled" id="Empanelment">
                        <li>
                          <a href="http://127.0.0.1:8000/fresh-empanelment"><i class="fa fa-angle-right" aria-hidden="true"></i> Add</a>
                        </li>
                         <li>
                          <a href="http://127.0.0.1:8000/vendor-empanelment"><i class="fa fa-angle-right" aria-hidden="true"></i> Renewal</a>
                        </li>

                      </ul>
                    </li>
                   <li>
                      <a href="#RO" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-angle-right" aria-hidden="true"></i> Release Order</a>
                      <ul class="collapse list-unstyled" id="RO">

                        <li>
                          <a href="http://127.0.0.1:8000/release-order-list"><i class="fa fa-angle-right" aria-hidden="true"></i> List</a>
                        </li>

                      </ul>
                    </li>
                                    
                </ul>
                <div class="footer">

                  Copyright &copy; 2021 All rights reserved  
                </p>
              </div>
            </div>
          </nav>     <!-- Page Content  -->
        <div id="content" class="">
            <nav class="navbar navbar-expand-lg navbar-light shadow">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-primary">
                        <i class="fa fa-bars"></i>
                        <span class="sr-only">Toggle Menu</span>
                    </button>

                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fa fa-bars"></i>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                            <!-- <li class="nav-item">
                                <a class="nav-link" href="#"><i class="fa fa-fw fa-home"></i> Home</a>
                            </li> 
                            <li class="nav-item">
                                <a class="nav-link" href="#"><i class="fa fa-fw fa-key"></i> Change Password</a>
                            </li> -->
                                                        <li class="nav-item">
                                <a style="color:#d01010" class="nav-link" href="http://127.0.0.1:8000/logout"><i class="fa fa-fw fa-power-off"></i> Logout</a>
                            </li>
                                                    </ul>
                    </div>
                </div>
            </nav>
            <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-12">
          <!--<h1>Application Form for Fresh Empanelment of Newspaper</h1>-->
        </div>
      </div>
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-default">
            <div class="card-header">
              <h3 class="card-title">Fresh empanelment of AV Producers (AV) EMPST7</h3>
              
            </div>
            <!-- /.end card-header -->
            <div class="card-body p-0">
              <form method="post" action="" id="av_media_producers">
               
                  <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                      <a class="nav-link active show" data-toggle="tab" href="#tab1">Basic Information</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" data-toggle="tab" href="#tab2">Print Information</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" data-toggle="tab" href="#tab3">Account Details</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" data-toggle="tab" href="#tab4">Upload Document</a>
                    </li>
                  </ul>
                  <div class="tab-content">
                    <!-- your steps content here -->
                    <div id="tab1" class="content pt-3 tab-pane active show" role="tabpanel" aria-labelledby="logins-part-trigger">
                      <div class="row">
                        <div class="col-md-12">
                          <h4>Category :-</h4>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label>Category Applied For</label>
                            <select name="category" id="category" class="form-control select2bs4" style="width: 100%;">
                              <option value=" ">Please Select</option>
                              <option value="0">A</option>
                              <option value="1">B</option>
                              <option value="2">C</option>
                              <option value="3">Special Category</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="other_category">(Int) Do you have branch office/ offices other than indicated above in Delhi or outside Delhi (If Yes, given details)</label>
                            <input type="text" name="other_category" placeholder="Enter Other Category" onkeypress="return onlyNumberKey(event);" class="form-control">
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-md-12">
                          <h4>Contact Details :-</h4>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="name_executive_producers">Name of the executive producers</label>
                            <input type="text" name="name_executive_producers" placeholder="Enter Name Executive Producers" class="form-control" onkeypress="return onlyAlphabets(event,this);">
                          </div>
                        </div>
                        <div class="col-md-6"></div>
                        <div class="col-md-12">
                          <h5>Name of The Organization :</h5>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="office_address">Office Address In Full </label>
                            <textarea type="text" name="office_address" rows="2" placeholder="Enter Office Address In full" class="form-control" onkeypress="return onlyAlphabets(event,this);" maxlength="220"></textarea>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="residential_address">Residential Address of The Executive Producer</label>
                            <input type="text" name="residential_address" placeholder="Enter Residential Address of The Executive Producer" onkeypress="return onlyAlphabets(event,this);" class="form-control">
                          </div>
                        </div>
                        <div class="col-md-12">
                          <h5>Telephone No. :</h5>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="office_telephone_no">Office Telephone</label>
                            <input type="text" name="office_telephone_no" placeholder="Enter Office" class="form-control" onkeypress="return onlyNumberKey(event)" maxlength="15">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="resident_telephone_no">Resident Telephone</label>
                            <input type="text" name="resident_telephone_no" placeholder="Enter Resident" class="form-control" onkeypress="return onlyNumberKey(event)" maxlength="15">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="fax_noo">Fax No. / फ़ैक्स नंबर</label>
                            <input type="text" name="fax_noo" placeholder="Enter Fax No." class="form-control" id="fax_noo" onkeypress="return onlyNumberKey(event)" maxlength="15">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="mobile">Mobile No./ मोबाइल नंबर</label>
                            <input type="text" name="mobile" placeholder="Enter Mobile" class="form-control" id="mobile" onkeypress="return onlyNumberKey(event)" maxlength="10">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="email">E-Mail Id / ई-मेल आईडी</label>
                            <input type="text" name="email" placeholder="Enter E-Mail Id" class="form-control" id="email">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="have_office">Branch office / offices other than indicated above in Delhi or outside Delhi</label>
                            <input id="have_office" name="have_office" placeholder="Enter Office Details" class="form-control" type="text">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="contact_person">Contact Person</label>
                            <input id="contact_person" name="contact_person" placeholder="Enter Contact Person" class="form-control" type="text" maxlength="50">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="telephone_no">Telephone No.</label>
                            <input id="telephone_no" name="phone" placeholder="Enter Telephone No." class="form-control" type="text" maxlength="15" onkeypress="return onlyNumberKey(event)">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="Contact_Person_Fax">Fax No.</label>
                            <input id="Contact_Person_Fax" onkeypress="return onlyNumberKey(event)" name="Contact_Person_Fax" placeholder="Enter Office Details" class="form-control" type="text" maxlength="15">
                          </div>
                        </div>
                      </div>
                      <!--  <button class="btn btn-primary media_producers-next-button" onclick="stepper.next()">Next</button> -->
                      <input type="hidden" name="tab_one" id="tab-one" value="1">
                      <a class="btn btn-primary media-producers-next-button" id="tab_1" tab1-one="1">Next</a>
                    </div>
                    <div id="tab2" class="content pt-3 tab-pane" role="tabpanel" aria-labelledby="logins-part-trigger">
                      <div class="row col-md-12">
                        <h5>Legal Status of Organization :-</h5>
                      </div>
                      <br>
                      <div class="row">
                        <div class="col-md-12">
                          <!-- radio -->
                          <div class="form-group clearfix">
                            <label for="organization_registered">If your organization registered under companies act? / क्या प्रेस का स्वामित्व अखबार के मालिक के पास है? ? </label>
                            <br>
                            <div class="icheck-primary d-inline">
                              <input type="radio" id="organization_registered1" name="organization_register" value="1">
                              <label for="organization_registered1">Yes / हाँ </label>&nbsp;&nbsp;
                            </div>
                            <div class="icheck-primary d-inline">
                              <input type="radio" id="organization_registered2" name="organization_register" value="0">
                              <label for="organization_registered2">No / नहीं</label>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row" id="partnership_firm" style="display:none">
                        <div class="col-md-12">
                          <h5>Partnership Firm :</h5>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="partnership_firm_state">State</label>
                            <select name="partnership_firm_state" class="form-control select2bs4" style="width: 100%;">
                              <option value=" ">Please Select</option>
                              <option value="A">A</option>
                              <option value="B">B</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="partners_address">Address of Partners</label>
                            <textarea type="text" name="partners_address" placeholder="Enter Address of Partners" rows="2" class="form-control"></textarea>
                          </div>
                        </div>
                        <div class="col-md-12">
                          <h5>if Company :</h5>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="company_state">State</label>
                            <select name="company_state" class="form-control select2bs4" style="width: 100%;">
                              <option value=" ">Please Select</option>
                              <option value="A">A</option>
                              <option value="B">B</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="directors_address">Address of Directors</label>
                            <textarea type="text" name="directors_address" placeholder="Enter Address of Directors" rows="2" class="form-control"></textarea>
                          </div>
                        </div>
                      </div>
                      <div class="row" id="section_a">
                        <div class="col-md-12">
                          <h5>Eligibility Criteria :-</h5>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="net_worth">Net worth (for A/B/C categories)</label>
                            <input type="text" name="net_worth" placeholder="Enter Net worth (for A/B/C categories)" class="form-control" id="net_worth_a">
                            <span>(Pl. see annexure for definition of net worth and minimum net worth for each category, along with documentary proof required)</span>
                          </div>
                        </div>
                        <div class="col-md-12">Professional experience (For A & B Categories) (Pl. see guideline for professional experience criteria for each category)</div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="details_programme">Details of Programme</label>
                            <input type="text" name="details_programme" placeholder="Enter Details of Programme" class="form-control" id="details_programme_a">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="Channel">Channel in Which Telecast/Broadcast </label>
                            <input type="text" name="Channel" placeholder="Enter Channel in which telecast/broadcast ." class="form-control" id="Channel_a">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="telecast_date">Date/Time of Telecast</label>
                            <input type="text" name="telecast_date" placeholder="DD/MM/YYYY" class="form-control" id="datepicker1_a">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="trp">TRP Ratings of Programme </label>
                            <input type="text" name="TRP" placeholder="Enter TRP Ratings of Programme" class="form-control" id="TRP_a">
                          </div>
                        </div>
                      </div>
                      <!-- end abc -->
                      <div class="row" id="section_b" style="">
                        <div class="col-md-12">
                          <h5>Eligibility Criteria :-</h5>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="net_worth">Net worth (for A/B/C categories)</label>
                            <input type="text" name="net_worth" placeholder="Enter Net worth (for A/B/C categories)" class="form-control" id="net_worth_b">
                            <span>(Pl. see annexure for definition of net worth and minimum net worth for each category, along with documentary proof required)</span>
                          </div>
                        </div>
                        <div class="col-md-12">Professional experience (For A &amp; B Categories) (Pl. see guideline for professional experience criteria for each category)</div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="details_programme">Details of Programme</label>
                            <input type="text" name="details_programme" placeholder="Enter Details of Programme" class="form-control" id="details_programme_b">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="Channel">Channel in Which Telecast/Broadcast </label>
                            <input type="text" name="Channel" placeholder="Enter Channel in which telecast/broadcast ." class="form-control" id="Channel_b">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="telecast">Date/Time of Telecast</label>
                            <input type="text" name="telecast_date" placeholder="DD/MM/YYYY" class="form-control hasDatepicker" id="datepicker1_b">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="trp">TRP Ratings of Programme </label>
                            <input type="text" name="TRP" placeholder="Enter TRP Ratings of Programme" class="form-control" id="TRP_b">
                          </div>
                        </div>
                        <div class="col-md-12">In case of application for category B, Please provide details of Studio below :</div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="address_studio">Address of Studio</label>
                            <textarea type="text" name="address_studio" id="address_studio_b" placeholder="Enter Address of Studio" rows="2" class="form-control"></textarea>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="landline_no">Telephone No. </label>
                            <input type="text" name="landline_no" placeholder="Enter Telephone No." class="form-control" id="landline_no_b" onkeypress="return onlyNumberKey(event)" maxlength="15">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="fax_no">Fax No.</label>
                            <input type="text" name="fax_no" id="fax_no_b" placeholder="Enter Fax No." rows="2" class="form-control" onkeypress="return onlyNumberKey(event)" maxlength="15">
                          </div>
                        </div>
                        <div class="col-md-12">
                          <!-- radio -->
                          <div class="form-group clearfix">
                            <label for="organization_registered">Is the studio fully owned by your own organization or in partnership with some other organization? </label>
                            <br>
                            <div class="icheck-primary d-inline">
                              <input type="radio" id="organization_registered_b" name="organization_registered">
                              <label for="organization_registered">Yes / हाँ </label>&nbsp;&nbsp;
                            </div>
                            <div class="icheck-primary d-inline">
                              <input type="radio" id="organization_registered3" name="organization_registered">
                              <label for="organization_registered3">No / नहीं</label>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row" id="section_c" style="">
                        <div class="col-md-12">
                          <h5>Eligibility Criteria :-</h5>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="net_worth">Net worth (for A/B/C categories)</label>
                            <input type="text" name="net_worth" placeholder="Enter Net worth (for A/B/C categories)" class="form-control" id="net_worth_c">
                            <span>(Pl. see annexure for definition of net worth and minimum net worth for each category, along with documentary proof required)</span>
                          </div>
                        </div>
                        <div class="col-md-12">In case of application for category C, you may provide :</div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="number_of_audio">The number of audio-spots/jingles/video spots produced by you in the last three years</label>
                            <input type="text" name="number_of_audio" class="form-control" id="number_of_audio_c">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="government_departments">How many of above has been for clients other than DAVP/Government Departments</label>
                            <input type="text" name="government_departments" class="form-control" id="government_departments_c">
                          </div>
                        </div>
                        <div class="col-md-12">If applying for special category, please give details below of professional experience :</div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="diploma_obtained">Institution from which Degree/Diploma was obtained</label>
                            <input type="text" name="institution_name" class="form-control" id="diploma_obtained_c">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="degree_year">Year in which obtained</label>
                            <input type="date" name="degree_year" placeholder="DD/MM/YYYY" class="form-control" id="year_obtained_c">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="degree_area">Area in which degree/diploma was obtained</label>
                            <input type="text" name="degree_area" class="form-control" id="area_c">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="list_of_award">Award if any</label>
                            <input type="text" name="list_of_award" class="form-control" id="award_if_any_c">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="list_of_programme">Name at least one programme in the applied category which has been produced by you, along with duration</label>
                            <input type="text" name="list_of_programme" class="form-control" id="one_programme_c">
                          </div>
                        </div>
                        <div class="col-md-12">
                          <h5>Preferred Area Work :</h5>
                        </div>  
                        <div class="col-md-6">
                          <div class="form-group">
                            <input type="checkbox" name="preferred_area_work[]"  id="social_sector_b" value="Social sector">
                            Social sector covering Health & Related issues, education, women & children issues, social & welfare issues etc.<br>
                            <input type="checkbox" name="preferred_area_work[]"  id="social_sector_b" value="Infrastructure sector">
                            Infrastructure sector covering water resources irrigation, agriculture, road safety, rural development etc.<br>
                            <input type="checkbox" name="preferred_area_work[]"  id="social_sector_b" value="Finance">
                            Finance and others like tax compliance, consumer right awareness etc<br>
                            <input type="checkbox" name="preferred_area_work[]"  id="social_sector_b" value="National Integration">
                            National Integration, Communal Harmony and Social Harmony<br>
                            <input type="checkbox" name="preferred_area_work[]"  id="social_sector_b" value="Defence">
                            Defence and national security related subjects<br>
                          </div>
                        </div>
                        <!--                  
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="social_sector">Social sector covering Health & Related issues, education, women & children issues, social & welfare issues etc.</label>
                            <input type="text" name="social_sector" class="form-control" id="social_sector_b">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="infrastructure_sector">Infrastructure sector covering water resources irrigation, agriculture, road safety, rural development etc.</label>
                            <input type="text" name="infrastructure_sector" class="form-control" id="infrastructure_sector_c">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="finance">Finance and others like tax compliance, consumer right awareness etc</label>
                            <input type="text" name="finance" class="form-control" id="finance_c">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="national_integration">National Integration, Communal Harmony and Social Harmony</label>
                            <input type="text" name="national_integration" class="form-control" id="national_integration_c">
                          </div>
                        </div>
                      -->
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="other_relevant_information">Any other relevant information </label>
                            <input type="text" name="other_relevant_information" class="form-control" id="other_relevant_information_c">
                          </div>
                        </div>
                      </div>
                      <a class="btn btn-primary reg-previous-button" id="previous_one">Previous</a>
                      <a class="btn btn-primary media-producers-next-button" id="tab_2">Next</a>
                    </div>
                    <div id="tab3" class="content pt-3 tab-pane" role="tabpanel" aria-labelledby="logins-part-trigger">
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="payee_name">Payee’s name, type of account and account number, name of bank and its branch with IFSC number for NEFT funds transfer</label>
                            <input type="text" class="form-control" name="payee_name">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="pan_number">Pan Number </label>
                            <input type="text" class="form-control" name="pan_number" id="dd_date" placeholder="Enter Pan Number" maxlength="15" onkeypress="return IsAlphaNumeric(event)">
                          </div>
                        </div>
                      </div>
                      <div class="row col-md-12">
                        <label>
                          <strong>Details of Demand Draft (non-refundable) drawn in favour of Accounts Officer DAVP, New Delhi as processing fee (Please see annexure for amount of fee etc.) :</strong>
                        </label>
                      </div>
                      <div class="row">
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="dd_no">Draft No.</label>
                            <input type="text" name="dd_no" class="form-control" placeholder="Enter Draft No.">
                          </div>
                        </div>
                        <div class="col-md-6">
                          <div class="form-group">
                            <label for="drawn_on_bank">Drawn on Bank </label>
                            <input type="text" name="drawn_on_bank" class="form-control" placeholder="Enter Drawn on Bank">
                          </div>
                        </div>
                      </div>
                      <a class="btn btn-primary reg-previous-button">Previous</a>
                      <a class="btn btn-primary media-producers-next-button" id="tab_3">Next</a>
                    </div>
                    <div id="tab4" class="content pt-3 tab-pane" role="tabpanel" aria-labelledby="information-part-trigger">
                      <div class="form-group">
                        <label for="exampleInputFile">Legal status of organization copy of the certificate of registration may be attached</label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file" name="registration_certificate" class="custom-file-input" id="registration_certificate">
                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                          </div>
                          <div class="input-group-append">
                            <span class="input-group-text">Upload</span>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputFile">Copy of income-tax return of last financial year to be attached </label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file" name="income_tax_return" class="custom-file-input" id="income_tax_return">
                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                          </div>
                          <div class="input-group-append">
                            <span class="input-group-text">Upload</span>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputFile">Cancelled cheque to be attached</label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file" name="cancelled_cheque" class="custom-file-input" id="cancelled_cheque">
                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                          </div>
                          <div class="input-group-append">
                            <span class="input-group-text">Upload</span>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="exampleInputFile">Bio-data of Key person of creative team (Please attach separate sheet)</label>
                        <div class="input-group">
                          <div class="custom-file">
                            <input type="file" name="bio_data" class="custom-file-input" id="bio_data">
                            <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                          </div>
                          <div class="input-group-append">
                            <span class="input-group-text">Upload</span>
                          </div>
                        </div>
                      </div>
                      <a class="btn btn-primary reg-previous-button">Previous</a>&nbsp; <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                  </div>
                
              </form>
            </div>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
    <!-- /.row -->
</div>
<!-- /.container-fluid -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->         </div>
    <!-- </div> -->
  
   </div>
      </div>
<script src="jquery1.min.js"></script>
<script src="jquery3.min.js"></script>
<script src="popper.js"></script>
<script src="bootstrap.min.js"></script>
<script src="main.js"></script>
<script src="jquery.backstretch.min.js "></script>
<script>
  $.backstretch("/theme/images/bg_v2.jpg", { speed: 500 });
</script>
<script src="select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<!-- InputMask -->
<script src="moment1.min.js"></script>
<script src="jquery.inputmask1.min.js"></script>

<!-- bootstrap color picker -->
<script src="bootstrap-colorpicker.min.js"></script>
<!-- dropzonejs -->
<!-- InputMask -->
<script src="moment.min.js"></script>
<script src="jquery.inputmask.min.js"></script>
<!-- date-range-picker -->
<script src="daterangepicker.js"></script>
<!-- Page specific script -->
<script src="jquery.validate.min.js"></script>
<!-- validation comman js  -->
<script src="validation_comman.js"></script>
<script src="bootstrap3-typeahead.min.js"></script>
<script src="bootstrap-multiselect.js"></script>
</body>
</html>
<!-- Page specific script -->
<link rel="stylesheet" href="jquery-ui.css">
<script src="jquery.validate.min.js"></script>
<script src="av_producers.js"></script>
<script src="audio_video.js"></script>
<script>
  $(function() {
    //Initialize Select2 Elements
    $('.select2').select2()
    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })
  })
  // BS-Stepper Init
  // document.addEventListener('DOMContentLoaded', function() {
  //   window.stepper = new Stepper(document.querySelector('.bs-stepper'))
  // })
  // $(function() {
  //   var $dp = $("#datepicker");
  //   $dp.datepicker({
  //     changeYear: true,
  //     changeMonth: true,
  //     minDate: 0,
  //     dateFormat: "dd/m/yy",
  //     yearRange: "-100:+20",
  //   });
  //   var $dp1 = $("#datepicker1");
  //   $dp1.datepicker({
  //     changeYear: true,
  //     changeMonth: true,
  //     minDate: 0,
  //     dateFormat: "dd/m/yy",
  //     yearRange: "-100:+20",
  //   });
  // });
  // DropzoneJS Demo Code End
  $(document).ready(function() {
    $("#organization_registered1").click(function() {
      if ($(this).is(":checked")) {
        $("#partnership_firm").show();
      }
    });
    $("#organization_registered2").click(function() {
      if ($(this).is(":checked")) {
        $("#partnership_firm").hide();
      }
    });
  });
</script> 



// Validation for alphabets only
function onlyAlphabets(e, t) {
    try {
        if (window.event) {
            var charCode = window.event.keyCode;
        }
        else if (e) {
            var charCode = e.which;
        }
        else { return true; }
        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32))
            return true;
        else
            return false;
    }
    catch (err) {
        alert(err.Description);
    }
  
  } 
  
  // validation for Alphanumeric only
  function isAlphaNumeric(e){ 
    var k;
    document.all ? k=e.keycode : k=e.which;
    return((k>47 && k<58)||(k>64 && k<91)||(k>96 && k<123)||k==0);
  }
  
  // validation for numerickey only
  function onlyNumberKey(evt) {  
    var ASCIICode = (evt.which) ? evt.which : evt.keyCode
    if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
    return false;
  return true;
  }
  
  // use for amount numeric and dot
  function isNumber(evt, element) {
  
    var charCode = (evt.which) ? evt.which : event.keyCode
    
    if (
      (charCode != 45 || $(element).val().indexOf('-') != -1) &&      // Check minus and only once.
      (charCode != 46 || $(element).val().indexOf('.') != -1) &&      // Check dot and only once.
      (charCode < 48 || charCode > 57))
      return false;
    
    return true;
    } 
	
	//Validation for number and .(Dot)
function onlyDotNumberKey(evt) {  
    var ASCIICode = (evt.which) ? evt.which : evt.keyCode
    if (ASCIICode > 31 && (ASCIICode < 46 || ASCIICode > 57))
    return false;
  return true;
  }
	
$(document).ready(function(){
    //when click first next
    $("#tab_1").click(function(){
        // var tab_one_id=$("#tab_1").attr('tab-one');
        // var tab_one_id=$("#tab-one").val();
        var data =new FormData($("#av_media_producers")[0]);
        $.ajax({
            url :'first_insert',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token1"]').attr('content')
            },
            data: data,
            contentType:false,
            cache:false,
            processData:false,
            success:function(data)
            {
                console.log(data);
            }
        });
    });


    $("#previous_one").click(function(){
        $("#tab-one").attr('value',0);
    });


    $("#tab_2,#tab3").click(function(){
        // var tab_one_id=$("#tab_1").attr('tab-one');
        // var tab_one_id=$("#tab-one").val();
        $("#tab-one").attr('value',0);
        var data =new FormData($("#av_media_producers")[0]);
        $.ajax({
            url :'first_insert',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token1"]').attr('content')
            },
            data: data,
            contentType:false,
            cache:false,
            processData:false,
            success:function(data)
            {
                console.log(data);
            }
        });
    })

});